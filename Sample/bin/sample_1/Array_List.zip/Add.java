package sample_1;

import java.util.ArrayList;
import java.util.Scanner;

public class Add 
{
	Scanner sc=new Scanner(System.in);
	static ArrayList<String> obj = new ArrayList<String>();
  void add()
 {
	 
	 System.out.println("The datas to be added");
	 obj.add(sc.nextLine());
	 
 }
}
