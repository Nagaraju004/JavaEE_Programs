package sample_1;

public class Show_Data extends Add
{
 static void show()
 {
	 for(int i=0;i<obj.size();i++)
		{
			System.out.println(obj.get(i));
		}
 }
}
