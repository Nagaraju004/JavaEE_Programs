package Book;
import java.util.*;
public class Lib 
{
 static HashMap<Integer,String> cse1=new HashMap<Integer,String>();
 static HashMap<Integer,String> cse2=new HashMap<Integer,String>();
 static HashMap<Integer,String> cse3=new HashMap<Integer,String>();
 static HashMap<Integer,String> cse4=new HashMap<Integer,String>();
 static HashMap<Integer,String> it1=new HashMap<Integer,String>();
 static HashMap<Integer,String> it2=new HashMap<Integer,String>();
 static HashMap<Integer,String> it3=new HashMap<Integer,String>();
 static HashMap<Integer,String> it4=new HashMap<Integer,String>();
 static HashMap<Integer,String> ece1=new HashMap<Integer,String>();
 static HashMap<Integer,String> ece2=new HashMap<Integer,String>();
 static HashMap<Integer,String> ece3=new HashMap<Integer,String>();
 static HashMap<Integer,String> ece4=new HashMap<Integer,String>();
 public static void lib()
 {
	
	 cse1.put(1,"Computer Programming");
	 cse1.put(2,"Introduction to Prograaming");
	 cse1.put(3,"Datastructures-1");
	 cse2.put(1,"Programming and Datastructures-1");
	 cse2.put(2,"Programming and Datastructures-2");
	 cse2.put(3,"Operating System");
	 cse3.put(1,"Computer Netwroks");
	 cse3.put(2,"Computer Architecture");
	 cse3.put(3,"Problem of Theory");
	 cse4.put(1,"Digital and Signal");
	 cse4.put(2,"Data Base Management System");
	 cse4.put(3,"Ad hoc and Sensor Networks");
	 ece1.put(1,"Electronic Devices");
	 ece1.put(2,"Introduction to Prograaming");
	 ece1.put(3,"Circuit Theory ");
	 ece2.put(1,"Programming and Datastructures-1");
	 ece2.put(2,"Programming and Datastructures-2");
	 ece2.put(2,"Digital and Siganl Theory");
	 ece3.put(3,"Electrical Engineering and Instrumentation");
	 ece3.put(1,"Computer Netwroks");
	 ece3.put(2,"Computer Architecture");
	 ece3.put(3,"Problem of Theory");
	 ece4.put(1,"Analog and Digital Communication");
	 ece4.put(2,"Digital Electronics");
	 ece4.put(3,"Operating System");
	 it1.put(1,"Digital Principles and System Design");
	 it1.put(2,"Introduction to Prograaming");
	 it1.put(3,"Computer Programming ");
	 it2.put(1,"Programming and Datastructures-1");
	 it2.put(2,"Environmental Science and Engineering");
	 it2.put(3,"Graphics and Multimedia");
	 it3.put(1,"Computer Netwroks");
	 it3.put(2,"Knowledge Management");
	 it3.put(3,"Web Programming");
	 it4.put(1,"Analog and Digital Communication");
	 it4.put(2,"Grid and Cloud Computing");
	 it4.put(3,"Ad hoc and Sensor Networks");

	 

	 
	 
 }
}
